#ifndef MAGOROXO_H
#define MAGOROXO_H
#include "Mago.h"

using namespace std;

class MagoRoxo : public Mago
{
public:
    MagoRoxo(string n, int p) : Mago(n, p) {}

    void LancarIlusao()
    {
        cout << nome << " lançou uma poderosa ilusão!\n";
    }
};

#endif
