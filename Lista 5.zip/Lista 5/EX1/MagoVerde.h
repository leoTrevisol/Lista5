#ifndef MAGOVERDE_H
#define MAGOVERDE_H
#include "Mago.h"

using namespace std;

class MagoVerde : public Mago
{
public:
    MagoVerde(string n, int p) : Mago(n, p) {}

    void FalarComAnimais()
    {
        cout << nome << " está conversando com animais.\n";
    }
};

#endif
