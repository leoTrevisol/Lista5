#include <iostream>
#include "MagoBranco.h"
#include "MagoVerde.h"
#include "MagoRoxo.h"
#include "MagoCinza.h"

using namespace std;

int main()
{

    MagoBranco mb("Alatar", 80);
    MagoVerde mv("Radagast", 70);
    MagoRoxo mr("Zorlak", 90);
    MagoCinza mc("Gandalf", 100);

    mb.Falar();
    mv.Andar();

    mb.LancarCura();
    mv.FalarComAnimais();
    mr.LancarIlusao();
    mc.TornarInvisivel();

    return 0;
}
