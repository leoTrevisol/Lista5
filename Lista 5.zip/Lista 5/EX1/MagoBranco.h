#ifndef MAGOBRANCO_H
#define MAGOBRANCO_H
#include "Mago.h"

using namespace std;

class MagoBranco : public Mago
{
public:
    MagoBranco(string n, int p) : Mago(n, p) {}

    void LancarCura()
    {
        cout << nome << " lançou uma magia de cura!\n";
    }
};

#endif
