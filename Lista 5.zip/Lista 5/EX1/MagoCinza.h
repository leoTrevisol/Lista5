#ifndef MAGOCINZA_H
#define MAGOCINZA_H
#include "Mago.h"

using namespace std;

class MagoCinza : public Mago
{
public:
    MagoCinza(string n, int p) : Mago(n, p) {}

    void TornarInvisivel()
    {
        cout << nome << " ficou invisível!\n";
    }
};

#endif
