#ifndef MAGO_H
#define MAGO_H
#include <iostream>
#include <string>

using namespace std;

class Mago
{
protected:
    string nome;
    int poder;

public:
    Mago(string n, int p) : nome(n), poder(p) {}

    void Andar()
    {
        cout << nome << " está andando...\n";
    }

    void Falar()
    {
        cout << nome << " diz: 'Saudações!'\n";
    }
};

#endif
