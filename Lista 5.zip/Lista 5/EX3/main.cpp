#include <iostream>
#include "Retangulo.h"
#include "Circulo.h"
#include "Triangulo.h"

using namespace std;

int main() {
    Retangulo r(5, 3);
    Circulo c(4);
    Triangulo t(6, 4, 5, 5, 6);

    cout << "Retângulo - Área: " << r.calcularArea() << ", Perímetro: " << r.calcularPerimetro() << endl;
    cout << "Círculo - Área: " << c.calcularArea() << ", Perímetro: " << c.calcularPerimetro() << endl;
    cout << "Triângulo - Área: " << t.calcularArea() << ", Perímetro: " << t.calcularPerimetro() << endl;

    return 0;
}
