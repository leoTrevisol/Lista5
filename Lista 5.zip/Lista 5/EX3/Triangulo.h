#ifndef TRIANGULO_H
#define TRIANGULO_H
#include "FormaGeometrica.h"

using namespace std;

class Triangulo : public FormaGeometrica {
private:
    float baseT;
    float altura;
    float lado1, lado2, lado3;

public:
    Triangulo(float b, float h, float l1, float l2, float l3)
    : FormaGeometrica("Triângulo"), baseT(b), altura(h), lado1(l1), lado2(l2), lado3(l3) {}

    float calcularArea() override {
        return (baseT * altura) / 2;
    }

    float calcularPerimetro() override {
        return lado1 + lado2 + lado3;
    }
};

#endif
