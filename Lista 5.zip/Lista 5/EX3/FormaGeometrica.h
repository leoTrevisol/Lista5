#ifndef FORMA_GEOMETRICA_H
#define FORMA_GEOMETRICA_H
#include <iostream>
#include <string>

using namespace std;

class FormaGeometrica {
protected:
    string nome;

public:
    FormaGeometrica(string n) : nome(n) {}
    virtual float calcularArea() = 0;
    virtual float calcularPerimetro() = 0;
};

#endif
