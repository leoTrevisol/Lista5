#ifndef CIRCULO_H
#define CIRCULO_H
#include "FormaGeometrica.h"
#include <cmath>

using namespace std;

class Circulo : public FormaGeometrica {
private:
    float raio;

public:
    Circulo(float r) : FormaGeometrica("Círculo"), raio(r) {}

    float calcularArea() override {
        return M_PI * raio * raio;
    }

    float calcularPerimetro() override {
        return 2 * M_PI * raio;
    }
};

#endif
