#ifndef RETANGULO_H
#define RETANGULO_H
#include "FormaGeometrica.h"

using namespace std;

class Retangulo : public FormaGeometrica {
private:
    float baseR;
    float altura;

public:
    Retangulo(float b, float a) : FormaGeometrica("Retângulo"), baseR(b), altura(a) {}

    float calcularArea() override {
        return baseR * altura;
    }

    float calcularPerimetro() override {
        return 2 * (baseR + altura);
    }
};

#endif
