#ifndef ANIMAL_H
#define ANIMAL_H
#include <iostream>
#include <string>

using namespace std;

class Animal
{
protected:
    string nome;
    string som_bicho;

public:
    Animal(string n, string s) : nome(n), som_bicho(s) {}

    virtual void fazerSom() = 0;
};

#endif
