#include <iostream>
#include "Gato.h"
#include "Cachorro.h"
#include "Galinha.h"

using namespace std;

int main()
{

    Gato g("Frajola");
    Cachorro c("Rex");
    Galinha gal("Clotilde");

    g.fazerSom();
    c.fazerSom();
    gal.fazerSom();

    return 0;
}
