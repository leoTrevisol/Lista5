#ifndef GATO_H
#define GATO_H
#include "Animal.h"

using namespace std;

class Gato : public Animal
{
public:
    Gato(string n) : Animal(n, "Miau!") {}

    void fazerSom() override
    {
        cout << nome << " faz: " << som_bicho << endl;
    }
};

#endif
