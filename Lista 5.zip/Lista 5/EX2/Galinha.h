#ifndef GALINHA_H
#define GALINHA_H
#include "Animal.h"

using namespace std;

class Galinha : public Animal
{
public:
    Galinha(string n) : Animal(n, "Cócórócó!") {}

    void fazerSom() override
    {
        cout << nome << " faz: " << som_bicho << endl;
    }
};

#endif
