#ifndef CACHORRO_H
#define CACHORRO_H
#include "Animal.h"

using namespace std;

class Cachorro : public Animal
{
public:
    Cachorro(string n) : Animal(n, "Au au!") {}

    void fazerSom() override
    {
        cout << nome << " faz: " << som_bicho << endl;
    }
};

#endif
